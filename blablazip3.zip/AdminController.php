<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Alat;
use App\Models\Kategori;
use App\Models\Log;

class AdminController extends Controller
{
    private function catatLog($pesan) {
        Log::create(['user_id' => Auth::id(), 'aksi' => $pesan]);
    }

    public function index(Request $request) {
        $search = $request->input('search');

        // LOGIKA PENCARIAN (CARI)
        // Jika ada search, filter user dan alat. Jika tidak, ambil semua.
        
        $users = User::when($search, function($query, $search) {
            return $query->where('name', 'like', "%{$search}%")
                         ->orWhere('email', 'like', "%{$search}%");
        })->latest()->get();

        $alats = Alat::with('kategori')->when($search, function($query, $search) {
            return $query->where('nama_alat', 'like', "%{$search}%");
        })->get();

        $kategoris = Kategori::all();
        $logs = Log::with('user')->latest()->limit(20)->get(); 

        return view('admin.dashboard', compact('users', 'kategoris', 'alats', 'logs'));
    }

    // --- FITUR CETAK ---
    public function cetak() {
        $users = User::all();
        $alats = Alat::with('kategori')->get();
        $logs = Log::with('user')->latest()->get();
        return view('admin.cetak', compact('users', 'alats', 'logs'));
    }

    // --- KATEGORI ---
    public function storeKategori(Request $req) {
        Kategori::create($req->all());
        $this->catatLog("Menambah Kategori: " . $req->nama_kategori);
        return back()->with('success', 'Kategori Ditambah');
    }
    public function editKategori($id) {
        $kategori = Kategori::findOrFail($id);
        return view('admin.edit_kategori', compact('kategori'));
    }
    public function updateKategori(Request $req, $id) {
        $k = Kategori::findOrFail($id);
        $k->update($req->all());
        $this->catatLog("Update Kategori ID: " . $id);
        return redirect()->route('admin.dashboard')->with('success', 'Kategori Diupdate');
    }
    public function destroyKategori($id) {
        Kategori::destroy($id);
        $this->catatLog("Hapus Kategori ID: " . $id);
        return back()->with('success', 'Kategori Dihapus');
    }

    // --- ALAT ---
    public function storeAlat(Request $req) {
        Alat::create($req->all());
        $this->catatLog("Menambah Alat: " . $req->nama_alat);
        return back()->with('success', 'Alat Ditambah');
    }
    public function editAlat($id) {
        $alat = Alat::findOrFail($id);
        $kategoris = Kategori::all();
        return view('admin.edit_alat', compact('alat', 'kategoris'));
    }
    public function updateAlat(Request $req, $id) {
        $a = Alat::findOrFail($id);
        $a->update($req->all());
        $this->catatLog("Update Alat: " . $req->nama_alat);
        return redirect()->route('admin.dashboard')->with('success', 'Alat Diupdate');
    }
    public function destroyAlat($id) {
        Alat::destroy($id);
        $this->catatLog("Hapus Alat ID: " . $id);
        return back()->with('success', 'Alat Dihapus');
    }

    // --- USER ---
    public function storeUser(Request $req) {
        User::create([
            'name' => $req->name,
            'email' => $req->email,
            'password' => bcrypt($req->password),
            'role' => $req->role
        ]);
        $this->catatLog("Menambah User: " . $req->name);
        return back()->with('success', 'User Ditambah');
    }
    public function editUser($id) {
        $user = User::findOrFail($id);
        return view('admin.edit_user', compact('user'));
    }
    public function updateUser(Request $req, $id) {
        $u = User::findOrFail($id);
        $data = [
            'name' => $req->name,
            'email' => $req->email,
            'role' => $req->role
        ];
        if($req->password) {
            $data['password'] = bcrypt($req->password);
        }
        $u->update($data);
        $this->catatLog("Update User: " . $req->name);
        return redirect()->route('admin.dashboard')->with('success', 'User Diupdate');
    }
    public function destroyUser($id) {
        User::destroy($id);
        $this->catatLog("Hapus User ID: " . $id);
        return back()->with('success', 'User Dihapus');
    }
}
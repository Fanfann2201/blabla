<x-app-layout>
    <x-slot name="header"><h2>Edit Alat</h2></x-slot>
    <div class="py-12 max-w-2xl mx-auto">
        <div class="bg-white p-6 shadow sm:rounded-lg">
            <form action="{{ route('admin.alat.update', $alat->id) }}" method="POST">
                @csrf @method('PUT')
                <div class="mb-4">
                    <label>Nama Alat</label>
                    <input type="text" name="nama_alat" value="{{ $alat->nama_alat }}" class="w-full border rounded p-2">
                </div>
                <div class="mb-4">
                    <label>Kategori</label>
                    <select name="kategori_id" class="w-full border rounded p-2">
                        @foreach($kategoris as $k)
                            <option value="{{ $k->id }}" {{ $alat->kategori_id == $k->id ? 'selected' : '' }}>{{ $k->nama_kategori }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-4">
                    <label>Stok</label>
                    <input type="number" name="stok" value="{{ $alat->stok }}" class="w-full border rounded p-2">
                </div>
                <button class="bg-blue-600 text-white px-4 py-2 rounded">Update</button>
            </form>
        </div>
    </div>
</x-app-layout>
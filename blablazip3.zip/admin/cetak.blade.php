<!DOCTYPE html>
<html>
<head>
    <title>Laporan Admin</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; font-size: 12px; }
        h2, h3 { text-align: center; }
        .header { margin-bottom: 30px; text-align: center; }
    </style>
</head>
<body onload="window.print()">
    <div class="header">
        <h2>LAPORAN DATA INVENTARIS & USER</h2>
        <p>Dicetak Tanggal: {{ date('d-m-Y') }}</p>
    </div>

    <h3>Data Barang</h3>
    <table>
        <thead><tr><th>Nama Alat</th><th>Kategori</th><th>Stok</th></tr></thead>
        <tbody>
            @foreach($alats as $a)
            <tr><td>{{ $a->nama_alat }}</td><td>{{ $a->kategori->nama_kategori }}</td><td>{{ $a->stok }}</td></tr>
            @endforeach
        </tbody>
    </table>

    <h3>Data User</h3>
    <table>
        <thead><tr><th>Nama</th><th>Email</th><th>Role</th></tr></thead>
        <tbody>
            @foreach($users as $u)
            <tr><td>{{ $u->name }}</td><td>{{ $u->email }}</td><td>{{ $u->role }}</td></tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard Peminjam') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            {{-- Pesan Sukses --}}
            @if(session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    {{ session('success') }}
                </div>
            @endif

            {{-- BAGIAN 1: FORM PEMINJAMAN (GRID) --}}
            <div>
                <h3 class="text-lg font-medium text-gray-900 mb-4">Ajukan Peminjaman</h3>
                
                {{-- Grid Layout: 1 kolom di HP, 3 kolom di Laptop --}}
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    @foreach($alats as $alat)
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 border border-gray-200">
                        <div class="flex justify-between items-start mb-4">
                            <h4 class="font-bold text-lg text-gray-800">{{ $alat->nama_alat }}</h4>
                            <span class="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded">Stok: {{ $alat->stok }}</span>
                        </div>

                        <form action="{{ route('pinjam.store') }}" method="POST">
                            @csrf
                            <input type="hidden" name="alat_id" value="{{ $alat->id }}">
                            
                            <div class="mb-3">
                                <label class="block text-sm font-medium text-gray-700 mb-1">Tgl Pinjam</label>
                                <input type="date" name="tanggal_pinjam" required 
                                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                            </div>

                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-1">Tgl Kembali</label>
                                <input type="date" name="tanggal_kembali" required 
                                    class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                            </div>

                            <button type="submit" 
                                class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded text-sm transition">
                                PINJAM
                            </button>
                        </form>
                    </div>
                    @endforeach
                </div>
            </div>

            <hr class="border-gray-300">

            {{-- BAGIAN 2: TABEL RIWAYAT --}}
            <div>
                <h3 class="text-lg font-medium text-gray-900 mb-4">Riwayat Peminjaman Saya</h3>
                
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Alat</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Durasi Pinjam</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @forelse($riwayats as $r)
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        {{ $r->alat->nama_alat }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {{ $r->tanggal_pinjam }} <span class="mx-1 text-gray-400">s/d</span> {{ $r->tanggal_kembali }}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        @if($r->status == 'pinjam')
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                                DIPINJAM
                                            </span>
                                        @elseif($r->status == 'kembali')
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                KEMBALI
                                            </span>
                                            <div class="text-xs text-gray-400 mt-1">
                                                Dikembalikan: {{ $r->tgl_dikembalikan }}
                                            </div>
                                        @else
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                                                {{ strtoupper($r->status) }}
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="3" class="px-6 py-4 text-center text-sm text-gray-500">
                                        Belum ada riwayat peminjaman.
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>
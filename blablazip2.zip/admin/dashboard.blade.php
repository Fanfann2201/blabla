<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard Admin') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Log Aktivitas</h3>
                <div class="h-48 overflow-y-auto bg-gray-50 rounded-md border border-gray-200 p-4">
                    @forelse($logs as $log)
                        <div class="text-sm py-1 border-b border-gray-100 last:border-0">
                            <span class="text-gray-500 text-xs font-mono mr-2">[{{ $log->created_at->format('d/m H:i') }}]</span>
                            <span class="font-bold text-indigo-700">{{ $log->user->name }}</span>:
                            <span class="text-gray-700">{{ $log->aksi }}</span>
                        </div>
                    @empty
                        <p class="text-gray-400 text-center text-sm italic">Belum ada aktivitas.</p>
                    @endforelse
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Kelola Kategori</h3>
                    
                    <form action="{{ route('admin.kategori.store') }}" method="POST" class="mb-6 flex gap-2">
                        @csrf
                        <input type="text" name="nama_kategori" placeholder="Nama Kategori Baru" required
                            class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        <button type="submit" 
                            class="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md text-sm transition">
                            Tambah
                        </button>
                    </form>

                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nama</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach($kategoris as $k)
                                <tr>
                                    <td class="px-4 py-2 text-sm text-gray-800">{{ $k->nama_kategori }}</td>
                                    <td class="px-4 py-2 text-right">
                                        <form action="{{ route('admin.kategori.destroy', $k->id) }}" method="POST" class="inline">
                                            @csrf @method('DELETE')
                                            <button onclick="return confirm('Hapus kategori ini?')" class="text-red-600 hover:text-red-900 text-sm font-medium">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Kelola Barang/Alat</h3>
                    
                    <form action="{{ route('admin.alat.store') }}" method="POST" class="mb-6 space-y-3">
                        @csrf
                        <div>
                            <input type="text" name="nama_alat" placeholder="Nama Alat" required
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        </div>
                        <div class="flex gap-2">
                            <select name="kategori_id" class="w-2/3 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                                @foreach($kategoris as $k) 
                                    <option value="{{ $k->id }}">{{ $k->nama_kategori }}</option> 
                                @endforeach
                            </select>
                            <input type="number" name="stok" placeholder="Stok" required
                                class="w-1/3 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        </div>
                        <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-md text-sm transition">
                            Simpan Alat
                        </button>
                    </form>

                    <div class="overflow-x-auto max-h-60 overflow-y-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50 sticky top-0">
                                <tr>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Barang</th>
                                    <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Kat</th>
                                    <th class="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Stok</th>
                                    <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                                @foreach($alats as $a)
                                <tr>
                                    <td class="px-4 py-2 text-sm font-medium text-gray-900">{{ $a->nama_alat }}</td>
                                    <td class="px-4 py-2 text-sm text-gray-500">{{ $a->kategori->nama_kategori }}</td>
                                    <td class="px-4 py-2 text-sm text-center text-gray-900">{{ $a->stok }}</td>
                                    <td class="px-4 py-2 text-right">
                                        <form action="{{ route('admin.alat.destroy', $a->id) }}" method="POST" class="inline">
                                            @csrf @method('DELETE')
                                            <button onclick="return confirm('Hapus alat ini?')" class="text-red-600 hover:text-red-900 text-xs font-bold uppercase">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

            </div> <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <h3 class="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Kelola User</h3>
                
                <form action="{{ route('admin.user.store') }}" method="POST" class="mb-6">
                    @csrf
                    <div class="grid grid-cols-1 md:grid-cols-5 gap-3 items-end">
                        <div class="md:col-span-1">
                            <label class="block text-xs text-gray-500 mb-1">Nama</label>
                            <input type="text" name="name" placeholder="Nama Lengkap" required
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        </div>
                        <div class="md:col-span-1">
                            <label class="block text-xs text-gray-500 mb-1">Email</label>
                            <input type="email" name="email" placeholder="email@contoh.com" required
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        </div>
                        <div class="md:col-span-1">
                            <label class="block text-xs text-gray-500 mb-1">Password</label>
                            <input type="text" name="password" placeholder="Password" required
                                class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                        </div>
                        <div class="md:col-span-1">
                            <label class="block text-xs text-gray-500 mb-1">Role</label>
                            <select name="role" class="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm">
                                <option value="peminjam">Peminjam</option>
                                <option value="petugas">Petugas</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="md:col-span-1">
                            <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 rounded-md text-sm transition">
                                + Tambah User
                            </button>
                        </div>
                    </div>
                </form>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            @foreach($users as $u)
                            <tr>
                                <td class="px-6 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{{ $u->name }}</td>
                                <td class="px-6 py-3 whitespace-nowrap text-sm text-gray-500">{{ $u->email }}</td>
                                <td class="px-6 py-3 whitespace-nowrap text-sm text-gray-500">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        {{ $u->role === 'admin' ? 'bg-red-100 text-red-800' : ($u->role === 'petugas' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800') }}">
                                        {{ ucfirst($u->role) }}
                                    </span>
                                </td>
                                <td class="px-6 py-3 whitespace-nowrap text-right text-sm font-medium">
                                    @if($u->id != Auth::id())
                                    <form action="{{ route('admin.user.destroy', $u->id) }}" method="POST" class="inline">
                                        @csrf @method('DELETE')
                                        <button onclick="return confirm('Hapus user ini?')" class="text-red-600 hover:text-red-900">Hapus</button>
                                    </form>
                                    @else
                                    <span class="text-gray-400 text-xs italic">Akun Anda</span>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</x-app-layout>